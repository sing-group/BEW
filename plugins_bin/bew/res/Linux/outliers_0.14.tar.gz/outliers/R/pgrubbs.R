"pgrubbs" <-
function(q,n,type = 10)

{

qgrubbs(q,n,type,rev=TRUE);

}

