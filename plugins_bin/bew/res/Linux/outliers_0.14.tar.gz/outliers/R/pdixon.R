"pdixon" <-
function(q,n,type = 10)

{

qdixon(q,n,type,rev=TRUE);

}

